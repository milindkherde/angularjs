A simple sample project using the Angular-Express-Seed
