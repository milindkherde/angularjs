module.exports = function(sequelize, DataTypes) {
	return sequelize.define('todo', {
		name: {
			type: DataTypes.STRING,
			allowNull: false,
			validate: {
				len: [1, 250]
			}
		},
		email: {
			type: DataTypes.STRING,
			allowNull: false,
			validate: {
				len: [1, 250]
			}
		},
			doj: {
			type: DataTypes.DATE,
			allowNull: false,
			validate: {
				len: [1, 250]
			}
		},
			income: {
			type: DataTypes.STRING,
			allowNull: false,
			validate: {
				len: [1, 250]
			}}
		
	});
};