window.module = angular.module('demo-app', []);
window.module.constant('jquery', window.jQuery);