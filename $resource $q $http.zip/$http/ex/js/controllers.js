app.controller('MainCtrl', function($scope, jsonService) {
   $scope.name = 'World';
   $scope.loading =true;
   
   jsonService.getjson().then(function(d) {
      console.log("bigctrl" + d);
      $scope.avengers = d[0].acteurs;
      $scope.loading =false;
   });

});