app.factory('jsonService', function($http) {
    return {

        getjson: function() {
           
            // $http returns a promise, which has a then function, which also returns a promise
            var promise = $http.get('https://api.mongolab.com/api/1/databases/lagrossetete/collections/avengers?apiKey=j0PIJH2HbfakfRo1ELKkX0ShST6_F78A')
            .then(function(response) {
                // The then function here is an opportunity to modify the response
                console.log("big" + response);
                // The return value gets picked up by the then in the controller.
                //
                // I do not know where he draws the term data
                // can be an expression of Angular
                //
                return response.data;
            });
            // Return the promise to the controller
            return promise;
        }
    }
});