var myApp = angular.module('myApp',['ngRoute','ContactController']);

myApp.config(function($routeProvider, $locationProvider) {
	
    $routeProvider.
      when('/login', {
	templateUrl: 'partials/login.html',
	controller: 'LoginController'
      }).
      when('/register', {
	templateUrl: 'partials/register.html',
	controller: 'ContactController'
      }).
      otherwise({
	redirectTo: '/login'
      });
});

myApp.run(function($rootScope, $location) {

    $rootScope.$on( "$routeChangeStart", function(event, next, current) {
      if ($rootScope.loggedInUser == null) {
        // no logged user, redirect to /login
        if ( next.templateUrl === "partials/login.html") {
        } else {
          $location.path("/login");
        }
      }
    });
  });
  
myApp.controller("LoginController", function($scope, $location, $rootScope) {
  $scope.login = function() {
    $rootScope.loggedInUser = $scope.username;
    $location.path("/register");
  };
});