angular.module("myAppService", []).service('ContactService', function ($http) {

    var uid = 1;
    var contacts = [];
    
    this.save = function (contact) {
        if (contact.id == null) {
            contact.id = uid++;
 
$http.post('/todos',contact).success (function(data){
							
						contacts.push(data);
					
				});


        } else {
            for (i in contacts) {
                if (contacts[i].id == contact.id) {
                    contacts[i] = contact;
                }
            }
        }
 	}

    this.get = function (id) {
        for (i in contacts) {
            if (contacts[i].id == id) {
                return contacts[i];
            }
        }
	}
    
    this.delete = function (id) {
        for (i in contacts) {
            if (contacts[i].id == id) {
                contacts.splice(i, 1);
            }
        }
    }

    this.list = function () {
        if(contacts.length === 0){
				$http.get('/todos').success (function(data){
					
					for(i in data){
						contacts.push(data[i]);
					}
					
					uid = contacts.length+1;
					
				});
			}	
			return contacts;
		}
});