angular.module("mainModule", [])
  .controller("mainController", function ($scope)
  {
    $scope.person = {};
  });