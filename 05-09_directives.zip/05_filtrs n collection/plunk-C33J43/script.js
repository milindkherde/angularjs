var myApp = angular.module('myApp',[]);
      myApp.controller('SampleController', function($scope){
            $scope.accounts = [ 
                    {id: 1, name: 'Cash'}, 
                    {id: 2, name: 'Bank Savings'} 
                  ];
            $scope.payees = [
                    {id:'1',name:'HouseRent', txnType:'EXPENDITURE'},
                    {id: '2', name:'InternetBill', txnType:'EXPENDITURE'}, 
                    {id:'3', name: 'PowerBill', txnType:'EXPENDITURE'}, 
                    {id:'4', name: 'Salary', txnType:'INCOME'}
                  ];
            $scope.transactions = [
                {id:'1', txnType:'EXPENDITURE', amount: 1000, account: $scope.accounts[0], payee: $scope.payees[0]},
                {id:'2', txnType:'EXPENDITURE', amount: 500, account: $scope.accounts[1], payee: $scope.payees[1]},
                {id:'3', txnType:'EXPENDITURE', amount: 1200, account: $scope.accounts[0], payee: $scope.payees[1]},
                {id:'4', txnType:'INCOME', amount: 5000, account: $scope.accounts[1], payee: $scope.payees[3]},
                {id:'5', txnType:'EXPENDITURE', amount:200, account: $scope.accounts[0], payee: $scope.payees[2]}

            ];
            
            
      });
      
      myApp.filter('expenditurePayeeFilter', [function($filter) {
                return function(inputArray, searchCriteria, txnType){         
                    if(!angular.isDefined(searchCriteria) || searchCriteria === ''){
                        return inputArray;
                    }         
                    var data=[];
                    angular.forEach(inputArray, function(item){             
                        if(item.txnType == txnType){
                            if(item.payee.name.toLowerCase().indexOf(searchCriteria.toLowerCase()) != -1){
                                data.push(item);
                            }
                        }
                    });      
                 return data;
               };
             }]);